import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../models/employee';

@Component({
  selector: 'app-pipe-sample',
  templateUrl: './pipe-sample.component.html',
  styleUrls: ['./pipe-sample.component.css'],
})
export class PipeSampleComponent {
  employee: Employee;
  names: string[];
  searchText!: string;
  constructor(private router: Router) {
    this.employee = new Employee(101, 'Anupam', 25000, new Date(2021, 3, 15));
    this.names = ['Anupam', 'Anuran', 'Chintan', 'Suprajata', 'Soumya'];
  }

  redirect() {
    this.router.navigate(['route', this.employee.id], {
      queryParams: { city: 'mumbai', country: 'india' },
    });
  }
}
