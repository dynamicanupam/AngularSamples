import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-customer-table',
  templateUrl: './customer-table.component.html',
  styleUrls: ['./customer-table.component.css'],
})
export class CustomerTableComponent {
  @Input('customers')
  customerList: string[];

  @Output()
  onSelectCustomer: EventEmitter<string>;

  constructor() {
    this.customerList = [];
    this.onSelectCustomer = new EventEmitter<string>();
  }

  selectCustomer(customerName: string) {
    this.onSelectCustomer.emit(customerName);
  }
}
