import { Component, ElementRef, ViewChild } from '@angular/core';
import { CustomerTableComponent } from '../customer-table/customer-table.component';

@Component({
  selector: 'app-customer-add',
  templateUrl: './customer-add.component.html',
  styleUrls: ['./customer-add.component.css'],
})
export class CustomerAddComponent {
  customerName: string;
  customerList: string[];

  @ViewChild('clist')
  customerListComp!: CustomerTableComponent;

  @ViewChild('errorMessage')
  alertDiv!: ElementRef;

  constructor() {
    this.customerList = [];
    this.customerName = '';
  }

  addCustomer() {
    //this.customerList.push(this.customerName);
    this.customerListComp.customerList.push(this.customerName);

    this.alertDiv.nativeElement.innerText = 'New Customer Added';

    setTimeout(() => {
      this.alertDiv.nativeElement.innerText = '';
    }, 2000);
  }

  readData(data: string) {
    this.customerName = data;
  }
}
