import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-routing-sample',
  templateUrl: './routing-sample.component.html',
  styleUrls: ['./routing-sample.component.css'],
})
export class RoutingSampleComponent implements OnInit {
  Id: string | undefined;
  City!: string;
  Country!: string;
  constructor(private activatedRoute: ActivatedRoute) {
    this.activatedRoute.params.subscribe((data) => {
      this.Id = data['id'];
    });

    this.activatedRoute.queryParams.subscribe((data) => {
      this.City = data['city'];
      this.Country = data['country'];
    });
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
}
