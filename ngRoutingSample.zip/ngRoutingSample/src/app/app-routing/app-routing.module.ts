import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PipeSampleComponent } from '../pipe-sample/pipe-sample.component';
import { CustomerAddComponent } from '../data-sharing/customer-add/customer-add.component';
import { RouterModule, Routes } from '@angular/router';
import { RoutingSampleComponent } from '../routing-sample/routing-sample.component';
import { PersonalComponent } from '../routing-sample/personal/personal.component';

const routes: Routes = [
  { path: 'employee', component: PipeSampleComponent },
  { path: 'customer/add', component: CustomerAddComponent },
  {
    path: 'route/:id',
    component: RoutingSampleComponent,
    children: [{ path: 'personal', component: PersonalComponent }],
  },
  {
    path: 'admin',
    loadChildren: () =>
      import('../modules/admin/admin.module').then((x) => x.AdminModule),
  },
  { path: '**', redirectTo: '' },
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forRoot(routes)],

  exports: [RouterModule],
})
export class AppRoutingModule {}
