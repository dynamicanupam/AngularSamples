import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { PipeSampleComponent } from './pipe-sample/pipe-sample.component';
import { MycustomPipe } from './custom/mycustom.pipe';
import { FormsModule } from '@angular/forms';
import { CustomerAddComponent } from './data-sharing/customer-add/customer-add.component';
import { CustomerTableComponent } from './data-sharing/customer-table/customer-table.component';
import { AppRoutingModule } from './app-routing/app-routing.module';
import { MenuComponent } from './menu/menu.component';
import { RoutingSampleComponent } from './routing-sample/routing-sample.component';
import { PersonalComponent } from './routing-sample/personal/personal.component';

@NgModule({
  declarations: [
    AppComponent,
    PipeSampleComponent,
    MycustomPipe,
    CustomerAddComponent,
    CustomerTableComponent,
    MenuComponent,
    RoutingSampleComponent,
    PersonalComponent,
  ],
  imports: [BrowserModule, FormsModule, AppRoutingModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
