import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mycustom',
})
export class MycustomPipe implements PipeTransform {
  /* Example 1
  transform(date: Date, format: string): string {
    let todayOffset = new Date().getTime();
    let pardateTimeOffset = date.getTime();
    let diff = todayOffset - pardateTimeOffset;

    let oneDay = 1000 * 60 * 60 * 24;
    if (format.toLowerCase() == 'm')
      return Math.floor(diff / (oneDay * 31)) + ' Months';
    else if (format.toLowerCase() == 'd')
      return Math.floor(diff / oneDay) + ' Days';
    else return Math.floor(diff / (oneDay * 365)) + ' Years';
  }
  */

  transform(value: any, ...args: string[]): string[] {
    let searchText = args[0];
    console.log(searchText);
    return value.filter((f: string | string[]) => f.indexOf(searchText) != -1);
  }
}
