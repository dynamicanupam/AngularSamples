import { Component } from '@angular/core';
import { Employee } from '../models/employee';

@Component({
  selector: 'app-pipe-sample',
  templateUrl: './pipe-sample.component.html',
  styleUrls: ['./pipe-sample.component.css'],
})
export class PipeSampleComponent {
  employee: Employee;
  names: string[];
  searchText!: string;
  constructor() {
    this.employee = new Employee(101, 'Anupam', 25000, new Date(2021, 3, 15));
    this.names = ['Anupam', 'Anuran', 'Chintan', 'Suprajata', 'Soumya'];
  }
}
