export class Employee 
{ 
    id: number | undefined; 
    name: string | undefined; 
    salary: number | undefined; 
    dateOfJoin!: Date ; 
    
    constructor();
    constructor(id: number, name: string, sal: number, doj: Date) ;
    
    constructor(id?: number, name?: string, sal?: number, doj?: Date) 
    { 
        if (id != null && name != null && sal != null && doj != null){
            this.id = id; 
            this.name = name; 
            this.salary = sal; 
            this.dateOfJoin = doj; 
        }
    } 
} 